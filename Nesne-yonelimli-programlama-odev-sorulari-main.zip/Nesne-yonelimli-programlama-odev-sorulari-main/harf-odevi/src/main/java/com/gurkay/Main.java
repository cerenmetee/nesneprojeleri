package com.gurkay;

public class Main {
    public static void main(String[] args) {
        //�smi yazdıralım
        AsciiArtPrinter asciiArtPrinter = new AsciiArtPrinter();
        asciiArtPrinter.yazdir("GURKAY");
    }
}
